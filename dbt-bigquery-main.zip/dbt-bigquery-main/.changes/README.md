# CHANGELOG

To view information about the changelog operation we suggest reading this [README](https://github.com/dbt-labs/dbt-bigquery/blob/main/.changes/README.md) found in `dbt-bigquery`.
