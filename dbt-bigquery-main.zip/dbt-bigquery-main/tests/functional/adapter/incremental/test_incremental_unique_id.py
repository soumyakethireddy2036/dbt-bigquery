from dbt.tests.adapter.incremental.test_incremental_unique_id import BaseIncrementalUniqueKey


class TestUniqueKeyBigQuery(BaseIncrementalUniqueKey):
    pass
