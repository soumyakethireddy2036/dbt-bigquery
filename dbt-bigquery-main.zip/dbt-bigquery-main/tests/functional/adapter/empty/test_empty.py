from dbt.tests.adapter.empty.test_empty import BaseTestEmpty, BaseTestEmptyInlineSourceRef


class TestBigQueryEmpty(BaseTestEmpty):
    pass


class TestBigQueryEmptyInlineSourceRef(BaseTestEmptyInlineSourceRef):
    pass
