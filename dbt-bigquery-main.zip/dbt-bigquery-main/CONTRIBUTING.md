# Contributing to `dbt-bigquery`

This repository has moved into [dbt-labs/dbt-adapters](https://www.github.com/dbt-labs/dbt-adapters).
Please refer to that repo for a guide on how to contribute to `dbt-bigquery`.
